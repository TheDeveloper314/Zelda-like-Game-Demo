import pygame
from settings import *

class Weapon(pygame.sprite.Sprite):
	def __init__(self, surface, player_hitbox, state,groups):
		super().__init__(groups)
		self.category = "weapon"
		self.image = surface
		if state == "up":
			self.rect = self.image.get_rect(midbottom = player_hitbox.midtop + pygame.math.Vector2((-15, 0)))
		elif state == "down":
			self.rect = self.image.get_rect(midtop = player_hitbox.midbottom + pygame.math.Vector2((-15, 0)))
		elif state == "right":
			self.rect = self.image.get_rect(midleft = player_hitbox.midright + pygame.math.Vector2((0, 15)))
		else:
			self.rect = self.image.get_rect(midright = player_hitbox.midleft + pygame.math.Vector2((0, 15)))
