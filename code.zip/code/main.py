import pygame, sys
from settings import *
from level import Level
from game_over_screen import GameOverScreen

class Game():
	def __init__(self):
		pygame.init()
		self.title = "Zelda-ish"
		self.screen = pygame.display.set_mode((width, height))
		self.clock = pygame.time.Clock()
		self.level = Level(self.kill_screen)
		pygame.display.set_caption(self.title)
		self.game_over = True
		self.game_over_screen = GameOverScreen()

		# graphics set-up
		self.player_graphics = self.game_over_screen.generate_player_image()
		self.title_graphics = self.game_over_screen.generate_text(self.title, 100)
		self.cont_graphics = self.game_over_screen.generate_text("Press Space to Play!", 600)

		# sound
		main_audio = pygame.mixer.Sound("../audio/main.ogg")
		main_audio.set_volume(0.2)
		main_audio.play(loops = -1)

	def upgrade_menu_navigation(self, event):
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_RIGHT:
				self.level.ui.upgrade_index += 1
				if self.level.ui.upgrade_index >= len(list(self.level.player.max_stats.keys())):
					self.level.ui.upgrade_index = len(list(self.level.player.max_stats.keys())) - 1

			if event.key == pygame.K_LEFT:
				self.level.ui.upgrade_index -= 1
				if self.level.ui.upgrade_index < 0:
					self.level.ui.upgrade_index = 0

	def upgrade_player_stat(self, event):
		if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
			upgrade_cost = self.level.player.upgrade_cost[list(self.level.player.upgrade_cost.keys())[self.level.ui.upgrade_index]]
			if self.level.player.stats["exp"] >= upgrade_cost:
				stat = self.level.player.max_stats[list(self.level.player.upgrade_cost.keys())[self.level.ui.upgrade_index]]
				max_stat = self.level.player.max_upgrade_stats[list(self.level.player.upgrade_cost)[self.level.ui.upgrade_index]]

				if stat < max_stat:
					stat *= 1.2
					upgrade_cost *= 1.4
					self.level.player.stats["exp"] -= upgrade_cost

				if stat > max_stat or stat >= max_stat * 0.98:
					stat = max_stat

				self.level.player.max_stats[list(self.level.player.upgrade_cost.keys())[self.level.ui.upgrade_index]] = stat
				self.level.player.upgrade_cost[list(self.level.player.upgrade_cost.keys())[self.level.ui.upgrade_index]] = int(upgrade_cost)
				self.level.player.max_upgrade_stats[list(self.level.player.upgrade_cost)[self.level.ui.upgrade_index]] = max_stat

	def kill_screen(self):
		self.level = None
		self.game_over = True

	def display_game_over_screen(self):
		self.screen.fill(bg_colour)
		self.screen.blit(self.player_graphics[0], self.player_graphics[1])
		self.screen.blit(self.title_graphics[0], self.title_graphics[1])
		self.screen.blit(self.cont_graphics[0], self.cont_graphics[1])

	def run(self):
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()

				if not self.game_over:
					if event.type == pygame.KEYDOWN:
						if event.key == pygame.K_m:
							self.level.pause()
							self.level.ui.upgrade_index = 0

					if self.level.paused:
						self.upgrade_menu_navigation(event)
						self.upgrade_player_stat(event)								

				else:
					if event.type == pygame.KEYDOWN:
						if event.key == pygame.K_SPACE:
							self.level = Level(self.kill_screen)
							self.game_over = False

			self.screen.fill(water_colour)
			if not self.game_over:
				self.level.run()
			else:
				self.display_game_over_screen()
			pygame.display.update()
			self.clock.tick(fps)

if __name__ == "__main__":
	game = Game()
	game.run()