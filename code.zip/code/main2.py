import pygame, sys
from settings import *
from level import Level

class Game():
	def __init__(self):
		pygame.init()
		self.title = "Zelda-ish"
		self.screen = pygame.display.set_mode((width, height))
		self.clock = pygame.time.Clock()
		self.level = Level()
		pygame.display.set_caption(self.title)

		# sound
		main_audio = pygame.mixer.Sound("../audio/main.ogg")
		main_audio.set_volume(0.2)
		main_audio.play(loops = -1)

	def upgrade_menu_navigation(self, event):
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_RIGHT:
				self.level.ui.upgrade_index += 1
				if self.level.ui.upgrade_index >= len(list(self.level.player.max_stats.keys())):
					self.level.ui.upgrade_index = len(list(self.level.player.max_stats.keys())) - 1

			if event.key == pygame.K_LEFT:
				self.level.ui.upgrade_index -= 1
				if self.level.ui.upgrade_index < 0:
					self.level.ui.upgrade_index = 0

	def upgrade_player_stat(self, event):
		if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
			upgrade_cost = self.level.player.upgrade_cost[list(self.level.player.upgrade_cost.keys())[self.level.ui.upgrade_index]]
			if self.level.player.stats["exp"] >= upgrade_cost:
				stat = self.level.player.max_stats[list(self.level.player.upgrade_cost.keys())[self.level.ui.upgrade_index]]
				max_stat = self.level.player.max_upgrade_stats[list(self.level.player.upgrade_cost)[self.level.ui.upgrade_index]]

				if stat < max_stat:
					stat *= 1.2
					upgrade_cost *= 1.4
					self.level.player.stats["exp"] -= upgrade_cost

				if stat > max_stat or stat >= max_stat * 0.98:
					stat = max_stat

				self.level.player.max_stats[list(self.level.player.upgrade_cost.keys())[self.level.ui.upgrade_index]] = stat
				self.level.player.upgrade_cost[list(self.level.player.upgrade_cost.keys())[self.level.ui.upgrade_index]] = int(upgrade_cost)
				self.level.player.max_upgrade_stats[list(self.level.player.upgrade_cost)[self.level.ui.upgrade_index]] = max_stat

	def run(self):
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()

				if event.type == pygame.KEYDOWN:
					if event.key == pygame.K_m:
						self.level.pause()
						self.level.ui.upgrade_index = 0

				if self.level.paused:
					self.upgrade_menu_navigation(event)
					self.upgrade_player_stat(event)								

				self.screen.fill(water_colour)
				self.level.run()
				pygame.display.update()
				self.clock.tick(fps)

if __name__ == "__main__":
	game = Game()
	game.run()