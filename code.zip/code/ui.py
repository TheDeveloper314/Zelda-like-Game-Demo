import pygame
from settings import *

class UI():
	def __init__(self):
		self.font = pygame.font.Font(font_path, font_size)
		self.display_surface = pygame.display.get_surface()
		self.screen_width = self.display_surface.get_size()[0]
		self.screen_height = self.display_surface.get_size()[1]
		self.upgrade_text_offset = pygame.math.Vector2(0, 30)
		self.upgrade_index = 0

	def display_bars(self, stat, value, max_value):
		bar_width = health_and_energy[f"{stat}_bar_width"]
		colour = health_and_energy[f"{stat}_bar_colour"]
		pos = health_and_energy[f"{stat}_y_pos"]

		bg_rect = pygame.Rect(10, pos, bar_width, bar_height)
		ratio = value / max_value
		bar_rect = bg_rect.copy()
		bar_rect.width = bg_rect.width * ratio

		pygame.draw.rect(self.display_surface, bg_colour, bg_rect)
		pygame.draw.rect(self.display_surface, colour, bar_rect)
		pygame.draw.rect(self.display_surface, border_colour, bg_rect, 3)

	def display_exp(self, exp):
		surface = self.font.render(str(int(exp)), False, text_colour)
		exp_rect = surface.get_rect(bottomright = (self.screen_width - 20, self.screen_height - 20))
		bg_rect = exp_rect.inflate(20, 20)

		pygame.draw.rect(self.display_surface, bg_colour, bg_rect)
		pygame.draw.rect(self.display_surface, border_colour, bg_rect, 3)
		self.display_surface.blit(surface, exp_rect)

	def display_equipment(self, type, image, active):
		if type == "weapon":
			bg_rect = pygame.Rect(20, self.screen_height - 100, equipment_bg_size, equipment_bg_size)
		else:
			bg_rect = pygame.Rect(90, self.screen_height - 90, equipment_bg_size, equipment_bg_size)

		equipment_rect = image.get_rect(center = bg_rect.center)

		pygame.draw.rect(self.display_surface, bg_colour, bg_rect)
		self.display_surface.blit(image, equipment_rect)

		if active:
			pygame.draw.rect(self.display_surface, border_colour, bg_rect, 3)
		else:
			pygame.draw.rect(self.display_surface, active_border_colour, bg_rect, 3)

	def display_upgrade_background(self, upgrade_stats, stats, max_stats):
		increment = self.screen_width / len(upgrade_stats.keys())
		width = increment * 0.75
		height = self.screen_height * 0.8
		top = self.screen_height * 0.1

		for index, (stat, value) in enumerate(list(upgrade_stats.items())):
			left = (increment * index) + ((increment - width) / 2)
			bg_rect = pygame.Rect(left, top, width, height)

			if index == self.upgrade_index:
				pygame.draw.rect(self.display_surface, active_bg_colour, bg_rect)
				self.display_upgrade_text(stat, value, bg_rect, active_text_colour)
				length = self.display_upgrade_bar(bg_rect, active_bar_colour)
				self.display_upgrade_level(stat, stats, max_stats, bg_rect, length, active_bar_colour)

			else:
				pygame.draw.rect(self.display_surface, bg_colour, bg_rect)
				self.display_upgrade_text(stat, value, bg_rect)
				length = self.display_upgrade_bar(bg_rect)
				self.display_upgrade_level(stat, stats, max_stats, bg_rect, length)

			pygame.draw.rect(self.display_surface, border_colour, bg_rect, 4)

	def display_upgrade_text(self, stat, value, rect, colour = text_colour):
		stat_surface = self.font.render(stat, False, colour)
		cost_surface = self.font.render(str(int(value)), False, colour)
		stat_rect = stat_surface.get_rect(center = rect.midtop + self.upgrade_text_offset)
		cost_rect = cost_surface.get_rect(center = rect.midbottom - self.upgrade_text_offset)
		self.display_surface.blit(stat_surface, stat_rect)
		self.display_surface.blit(cost_surface, cost_rect)

	def display_upgrade_bar(self, rect, colour = bar_colour):
		start_pos = rect.midtop + self.upgrade_text_offset * 2
		end_pos = rect.midbottom - self.upgrade_text_offset * 2
		points = (end_pos[1], start_pos[1])

		pygame.draw.line(self.display_surface, colour, start_pos, end_pos, 4)

		return points

	def display_upgrade_level(self, stat, stats, max_stats, rect, points, colour = bar_colour):
		offsetx = 15
		offsety = self.upgrade_text_offset[1] * 2
		left = rect.center[0] - offsetx
		width = offsetx * 2
		height = offsetx
		length = points[0] - points[1]

		top = ((1 - (stats[stat] / max_stats[stat])) * length) + points[1]
		rect = pygame.Rect(left, top, width, height)
		pygame.draw.rect(self.display_surface, colour, rect)


	def display(self, paused, player):
		self.display_bars("health", player.stats["health"], player.max_stats["health"])
		self.display_bars("energy", player.stats["energy"], player.max_stats["energy"])
		self.display_exp(player.stats["exp"])
		if not paused:
			self.display_equipment("weapon", player.arsenal[player.weapons[player.weapon_index]]["surfaces"]["full"], not player.weapon_change)
			self.display_equipment("magic", player.spells_surfaces[player.spell_type][0], not player.spell_change)

		else:
			# display upgrade menu
			self.display_upgrade_background(player.upgrade_cost, player.max_stats, player.max_upgrade_stats)