import pygame
from settings import *

class Tile(pygame.sprite.Sprite):
	def __init__(self, pos, groups, category, surface = pygame.Surface((tilesize, tilesize)), particles = None):
		super().__init__(groups)
		self.category = category
		self.image = surface
		self.hitbox_offset = hitbox_offset[category]
		if category == "object":
			self.rect = self.image.get_rect(topleft = (pos[0], pos[1] - tilesize))
			self.hitbox = self.rect.inflate(-20, self.hitbox_offset)
		else:
			self.rect = self.image.get_rect(topleft = pos)
			self.hitbox = self.rect.inflate(-10, self.hitbox_offset)
		self.particles = particles