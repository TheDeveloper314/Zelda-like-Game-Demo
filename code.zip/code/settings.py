# game setup
width    = 1280
height   = 720
fps      = 60
tilesize = 64
hitbox_offset = {
	"player": -26,
	"object": -50,
	"grass": -10,
	"invisible": 0
}

# ui
	# general dimensions
bar_height = 20
equipment_bg_size = 80

	# font
font_path = "../graphics/font/joystix.ttf"
font_size = 18

	# general colours
water_colour = "#71ddee"
bg_colour = "#222222"
border_colour = "#111111"
active_border_colour = "gold"
text_colour = "#EEEEEE"

	# upgrade menu
bar_colour = "#EEEEEE"
active_bg_colour = "#EEEEEE"
active_text_colour = "#111111"
active_bar_colour = "#111111"

	# health and energy
health_and_energy = {
	"health_bar_width": 200,
	"energy_bar_width": 150,
	"health_bar_colour": "red",
	"energy_bar_colour": "blue",
	"health_y_pos": 10,
	"energy_y_pos": 34
}

# magic
spells = {
	"flame": {"strength": 5, "cost": 20, "type": "black magic", "graphic": "../graphics/particles/flame/icon/", "audio": "../audio/flame.wav"},
	"heal": {"strength": 20, "cost": 10, "type": "white magic", "graphic": "../graphics/particles/heal/icon/", "audio": "../audio/heal.wav"}
}

# entities
entities = {
	"394": "player",
	"393": "spirit",
	"392": "raccoon",
	"391": "squid",
	"390": "bamboo"
}

# enemy data
monsters_data = {
	"spirit": {"health": 100, "damage": 8, "speed": 4, "resistance": 3, "attack_radius": 60, "notice_radius": 350,  "exp": 110, "attack_type": "thunder", "attack_audio": "../audio/attack/thunder.wav"},
	"raccoon": {"health": 300, "damage": 40, "speed": 2, "resistance": 3, "attack_radius": 120, "notice_radius": 400,  "exp": 250, "attack_type": "claw", "attack_audio": "../audio/attack/claw.wav"},
	"squid": {"health": 100, "damage": 20, "speed": 3, "resistance": 3, "attack_radius": 80, "notice_radius": 360,  "exp": 100, "attack_type": "slash", "attack_audio": "../audio/attack/slash.wav"},
	"bamboo": {"health": 70, "damage": 6, "speed": 3, "resistance": 3, "attack_radius": 50, "notice_radius": 300,  "exp": 120, "attack_type": "leaf_attack", "attack_audio": "../audio/attack/slash.wav"}
}