import pygame
from particles_effect import ParticlesEffect
from random import randint
from settings import *

class Magic():
	def __init__(self, spell, particles, pos, direction, groups):
		self.spell_type = spell
		self.school = spells[self.spell_type]["type"]
		self.frames = particles
		self.direction = direction
		self.player_position = pos
		self.groups = groups
		self.audio = pygame.mixer.Sound(spells[self.spell_type]["audio"])
		self.audio.set_volume(0.25) if self.school == "black magic" else self.audio.set_volume(0.3)

	def cast_offensive_directional(self):
		if self.direction == "up":
			direction = pygame.math.Vector2(0, -1)
		elif self.direction == "down":
			direction = pygame.math.Vector2(0, 1)
		elif self.direction == "right":
			direction = pygame.math.Vector2(1, 0)
		else:
			direction = pygame.math.Vector2(-1, 0)

		for i in range (1, 6):
			randomizer = pygame.math.Vector2(randint(-tilesize // 3, tilesize // 3), randint(-tilesize // 3, tilesize // 3))
			pos = self.player_position + (direction * tilesize * i) + randomizer
			ParticlesEffect(self.frames, pos, self.groups, "magic")

	def cast_heal(self):
		offset = pygame.math.Vector2(0, -40)
		ParticlesEffect(self.frames[0], self.player_position + offset, self.groups[0], "magic")
		ParticlesEffect(self.frames[1], self.player_position, self.groups[0], "magic")

	def cast_spell(self):
		if self.school == "black magic":
			self.cast_offensive_directional()
		elif self.school == "white magic":
			self.cast_heal()

		self.audio.play()
