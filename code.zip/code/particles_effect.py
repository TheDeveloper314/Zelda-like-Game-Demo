import pygame
from settings import *

class ParticlesEffect(pygame.sprite.Sprite):
	def __init__(self, particles, pos, groups, category):
		super().__init__(groups)
		self.animation_index = 0
		self.animation_speed = 0.15
		self.frames = particles
		self.category = category

		if self.frames:
			self.image = self.frames[self.animation_index]
			self.rect = self.image.get_rect(center = pos)
			
	def animate(self):
		if self.frames:
			self.animation_index += self.animation_speed
			if self.animation_index >= len(self.frames):
				self.kill()
			else:
				self.image = self.frames[int(self.animation_index)]

	def update(self):
		self.animate()
