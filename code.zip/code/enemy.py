import pygame
from support import *
from settings import *
from entity import Entity
from particles_effect import ParticlesEffect

class Enemy(Entity):
	def __init__(self, pos, groups, _id, category, obstacle_sprites, particles, increase_player_exp):
		super().__init__(groups, obstacle_sprites)
		self.category = category
		self.type = entities[_id]
		self.groups = groups	
		# stats
		self.stats = monsters_data[self.type].copy()
		# graphics set-up
		self.animations_path = f"../graphics/monsters/{self.type}/"
		self.animations = {
				"idle": [], "move": [], "attack": []
			}
		self.state = "idle"
		self.can_attack = True
		self.attack_cooldown = 350
		self.attack_time = 0
		self.player_damaged = False
		self.attack_particles = particles[monsters_data[self.type]["attack_type"]]
		self.death_particles = particles[self.type]

		self.import_animations()

		self.image = self.animations["idle"][0]
		x = pos[0]
		y = pos[1] - tilesize if self.type == "raccoon" else pos[1]
		self.rect = self.image.get_rect(topleft = (x, y))
		self.hitbox = self.rect.inflate(0, -20)

		# audio set-up
		self.death_audio = pygame.mixer.Sound("../audio/death.wav")
		self.death_audio.set_volume(0.15)
		self.attack_audio = pygame.mixer.Sound(monsters_data[self.type]["attack_audio"])
		self.attack_audio.set_volume(0.3)
		self.damaged_audio = pygame.mixer.Sound("../audio/hit.wav")
		self.damaged_audio.set_volume(0.05)

		self.player_position = None
		self.initial_vector = pygame.math.Vector2(pos)
		self.vector = self.initial_vector
		self.velocity = self.stats["speed"]

		# player interaction
		self.increase_player_exp = increase_player_exp

	def calculate_vector(self):
		player_vector = pygame.math.Vector2(self.player_position)
		self.vector = pygame.math.Vector2(self.rect.center)
		self.vector = player_vector - self.vector
		if self.damaged:
			self.vector *= -self.stats["resistance"]
			self.damaged_audio.play()

	def change_state(self):
		if self.vector.magnitude() <= self.stats["attack_radius"] and self.can_attack:
			if self.state != "attack":
				self.animation_index = 0
			self.state = "attack"
		elif self.vector.magnitude() <= self.stats["notice_radius"]:
			self.state = "move"
		else:
			self.state = "idle"

	def take_action(self):
		if self.state == "attack":
			if self.animation_played:
				self.attack_audio.play()
				self.player_damaged = True
				ParticlesEffect(self.attack_particles, self.player_position, self.groups[0], "particle")
				self.attack_time = pygame.time.get_ticks()
				self.can_attack = False
		elif self.state == "move":
			self.move()
		else:
			self.vector.update(0, 0)

	def destroy(self):
		if self.stats["health"] <= 0:
			ParticlesEffect(self.death_particles, self.rect.center, self.groups[0], "particle")
			self.kill()
			self.death_audio.play()
			self.increase_player_exp(monsters_data[self.type]["exp"])

	def update(self):
		self.calculate_vector()
		self.change_state()
		self.take_action()
		self.animate()
		self.cooldowns()
		self.destroy()