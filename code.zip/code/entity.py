import pygame
from support import *
from math import sin

class Entity(pygame.sprite.Sprite):
	def __init__(self, groups, obstacle_sprites):
		super().__init__(groups)
		# animation
		self.animation_index = 0
		self.animation_speed = 0.15

		self.obstacle_sprites = obstacle_sprites
		self.animation_played = False

		self.vulnerable = True
		self.damaged_time = 0
		self.invulnerability_time = 90
		self.damaged = False

	def move(self):
		if self.vector.magnitude() != 0:
			self.vector = self.vector.normalize()
		self.hitbox.x += self.vector.x * self.velocity
		self.collision("horizontal")
		self.hitbox.y += self.vector.y * self.velocity
		self.collision("vertical")
		self.rect.center = self.hitbox.center

	def animate(self):
		animation = self.animations[self.state]
		self.animation_index += self.animation_speed

		if self.animation_index >= len(animation):
			self.animation_played = True
			self.animation_index = 0
		else:
			self.animation_played = False
		self.image = self.animations[self.state][int(self.animation_index)]
		self.rect = self.image.get_rect(center = self.hitbox.center)
		self.hitbox = self.rect.inflate(0, -20)
		if not self.damaged:
			self.image.set_alpha(255)

	def get_damaged(self, damage):
		if self.vulnerable:
			self.stats["health"] -= damage
			self.damaged_time = pygame.time.get_ticks()
			self.vulnerable = False
			self.damaged = True

	def cooldowns(self):
		self.current_time = pygame.time.get_ticks()
		if (self.current_time - self.attack_time) >= self.attack_cooldown:
			if self.category == "player":
				self.attacking = False
				if self.weapon:
					self.weapon.kill()
					self.weapon = None
			else:
				self.can_attack = True

		if (self.current_time - self.damaged_time) >= self.invulnerability_time:
			self.vulnerable = True
			self.damaged = False

	def collision(self, direction):
		for sprite in self.obstacle_sprites:
			if self.hitbox.colliderect(sprite.hitbox):
				if direction == "horizontal":
						if self.vector.x > 0:
							self.hitbox.right = sprite.hitbox.left
				
						if self.vector.x < 0:
							self.hitbox.left = sprite.hitbox.right

				elif direction =="vertical":
						if self.vector.y > 0:
							self.hitbox.bottom = sprite.hitbox.top
						
						if self.vector.y < 0:
							self.hitbox.top = sprite.hitbox.bottom

	def flicker(self):
		opacity = sin(pygame.time.get_ticks())
		if opacity >= 0: alpha = 255
		else: alpha = 0

		self.image.set_alpha(alpha)

	def import_animations(self):
		for state in self.animations.keys():
			self.animations[state] = import_surfaces(f"{self.animations_path}{state}/")

	def attack_delay(self):
		if (self.current_time - self.attack_time) >= self.attack_cooldown * 3:
			return True
		return False