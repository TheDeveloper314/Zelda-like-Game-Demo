import pygame
from settings import *
from tile import Tile
from player import Player
from support import *
from random import choice, randint
from ui import UI
from enemy import Enemy
from particles_effect import ParticlesEffect

class Level:
	def __init__(self, kill_screen):
		self.visible_sprites = YSortCameraGroup()
		self.obstacle_sprites = pygame.sprite.Group()
		self.attackable_sprites = pygame.sprite.Group()
		self.attack_sprites = pygame.sprite.Group()
		self.keys = None
		self.kill_screen = kill_screen
		self.surfaces = {
			"grass": import_surfaces("../graphics/grass"),
			"objects": import_surfaces("../graphics/objects")
		}
		self.map = {
			"boundary": import_csv_file("../map/map_FloorBlocks.csv"),
			"grass": import_csv_file("../map/map_Grass.csv"),
			"objects": import_csv_file("../map/map_Objects.csv"),
			"entities": import_csv_file("../map/map_Entities.csv")
		}
		
		# monster surfaces
		self.enemy_surfaces = import_enemy_surfaces()
		
		# weapons
		self.arsenal = import_weapons()

		# particles
		self.world_particles = import_world_particles()
		
		self.create_map()
		self.ui = UI()
		self.paused = False

	def create_map(self):
		for layer, layout in self.map.items():
			for row_index, row in enumerate(layout):
				for col_index, col in enumerate(row):
					if col != "-1":
						x = col_index * tilesize
						y = row_index * tilesize
						if layer == "boundary":
							Tile((x, y), [self.obstacle_sprites], "invisible")
						elif layer == "grass":
							surface = choice(self.surfaces[layer])
							Tile((x, y), [self.visible_sprites, self.obstacle_sprites, self.attackable_sprites], "grass", surface, self.world_particles["grass"])
						elif layer == "objects":
							surface = self.surfaces[layer][int(col)]
							Tile((x, y), [self.visible_sprites, self.obstacle_sprites], "object", surface)
						elif layer == "entities":
							if entities[col] == "player":
								self.player = Player(
									(x, y),
									self.arsenal,
									[self.visible_sprites],
									self.obstacle_sprites,
									self.visible_sprites,
									self.attack_sprites,
									self.world_particles["player"],
									self.kill_screen
								)
							else:
								Enemy(
									(x, y),
									[self.visible_sprites,
									self.attackable_sprites],
									col,
									"enemy",
									self.obstacle_sprites,
									self.world_particles["monsters"],
									self.increase_player_exp
								)

	def get_player_position(self):
		for sprite in self.visible_sprites:
			if sprite.category == "enemy":
				sprite.player_position = self.player.rect.center

	def check_damage_collisions(self):
		if self.attack_sprites:
			for sprite in self.attack_sprites:
				collisions = pygame.sprite.spritecollide(sprite, self.attackable_sprites, False)
				for collided_sprite in collisions:
					if collided_sprite.category == "grass":
						collided_sprite.kill()
						self.generate_grass_particles(collided_sprite)						
					else: 
						collided_sprite.get_damaged(self.player.damage)
						collided_sprite.vulnerable = False

	def generate_grass_particles(self, collided_sprite):
		for i in range(3, randint(5, 6)):
			ParticlesEffect(
				choice(self.world_particles["grass"]["leaf"]),
				collided_sprite.rect.center - pygame.math.Vector2(0, randint(40, 50)),
				self.visible_sprites,
				"particle"
			)

	def flicker_sprites(self):
		for sprite in self.visible_sprites:
			if sprite.category == "player" or sprite.category == "enemy":
				if sprite.damaged:
					sprite.flicker()

	def check_player_damage(self):
		for sprite in self.visible_sprites:
			if sprite.category == "enemy":
				if sprite.player_damaged:
					self.player.get_damaged(sprite.stats["damage"])
					sprite.player_damaged = False

	def increase_player_exp(self, exp):
		self.player.stats["exp"] += exp

	def pause(self):
		self.paused = not self.paused

	def run(self):
		self.visible_sprites.custom_draw(self.player)
		self.ui.display(self.paused, self.player)

		# game running
		if not self.paused:
			self.get_player_position()
			self.check_damage_collisions()
			self.check_player_damage()
			self.flicker_sprites()
			self.visible_sprites.update()

class YSortCameraGroup(pygame.sprite.Group):
	def __init__(self):
		super().__init__()
		self.display_surface = pygame.display.get_surface()
		self.offset = pygame.math.Vector2()
		self.ground = pygame.image.load("../graphics/tilemap/ground.png").convert()
		self.ground_rect = self.ground.get_rect(topleft = (0, 0))

	def custom_draw(self, player):
		self.offset.x = player.rect.centerx - (self.display_surface.get_size()[0] // 2)
		self.offset.y = player.rect.centery - (self.display_surface.get_size()[1] // 2)

		# display ground
		self.display_surface.blit(self.ground, self.ground_rect.topleft - self.offset)

		# display tiles
		for sprite in sorted(self.sprites(), key = lambda sprite: sprite.rect.centery):
			self.display_surface.blit(sprite.image, sprite.rect.topleft - self.offset)