from csv import reader
from os import walk
import pygame
from settings import *

def import_csv_file(path):
	layout = []
	with open(path) as file:
		data = reader(file)
		for row in data:
			layout.append(list(row))
	return layout

def import_surfaces(path):
	surfaces = []
	for folder, folders_within, files in walk(path):
		for file in sorted(files):
			path = folder + "/" + file
			surface = pygame.image.load(path).convert_alpha()
			surfaces.append(surface)
		return surfaces

def import_weapons():
	weapons_path = "../graphics/weapons/"
	weapon_states = ["up", "down", "right", "left", "full"]

	weapons = {
		"axe": {"damage": 20, "cooldown": 300, "surfaces": {}},
		"lance": {"damage": 30, "cooldown": 400, "surfaces": {}},
		"rapier": {"damage": 8, "cooldown": 50, "surfaces": {}},
		"sai": {"damage": 10, "cooldown": 80, "surfaces": {}},
		"sword": {"damage": 15, "cooldown": 100, "surfaces": {}}
	}

	for weapon, details in weapons.items():
		for state in weapon_states:
			surface = pygame.image.load(f"{weapons_path}{weapon}/{state}.png").convert_alpha()
			details["surfaces"].update({state: surface})
	return weapons

def import_enemy_surfaces():
	states = ["idle", "move", "attack"]
	main_path = "../graphics/monsters"
	enemies = {entity: {state: import_surfaces(f"{main_path}/{entity}/{state}") for state in states} for entity in entities.values() if entity != "player"}
	return enemies

def import_world_particles():
	particles = {
		# player specific particles
		"player": {
			# magic
			"flame": None,
			"aura": None,
			"heal": None
		},
		
		# enemy specific particles
		"monsters": {
			# attacks
			"claw": None,
			"slash": None,
			"thunder": None,
			"sparkle": None,
			"leaf_attack": None,

			# monster deaths
			"spirit": None,
			"raccoon": None,
			"squid": None,
			"bamboo": None
		},
		# grass specific particles
		"grass": {"leaf": []}
	}

	for particle_group, values in particles.items():
		for particle_set in values.keys():
			if particle_set != "leaf":
				if particle_set == "squid":
					path = f"../graphics/particles/smoke_orange"
				elif particle_set == "spirit":
					path = f"../graphics/particles/nova"
				else:
					path = f"../graphics/particles/{particle_set}"
				particles[particle_group][particle_set] = import_surfaces(path)
			else:
				for i in range(1, 7):
					path = f"../graphics/particles/{particle_set}{i}"
					surfaces = import_surfaces(path)
					particles[particle_group][particle_set].append(surfaces)
					particles[particle_group][particle_set].append(flip_surfaces(surfaces))
	particles["grass"]["leaf"] = tuple(particles["grass"]["leaf"])
	return particles

def flip_surfaces(surfaces):
	flipped_surfaces = []
	for surface in surfaces:
		flipped_surface = pygame.transform.flip(surface, True, False)
		flipped_surfaces.append(flipped_surface)
	return flipped_surfaces
