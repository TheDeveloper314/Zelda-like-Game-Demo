import pygame
from support import import_surfaces
from weapon import *
from entity import Entity
from settings import *
from particles_effect import ParticlesEffect
from magic import Magic

class Player(Entity):
	def __init__(self, pos, arsenal, groups, obstacle_sprites, visible_sprites, attack_sprites, particles, kill_screen):
		super().__init__(groups, obstacle_sprites)
		self.category = "player"
		self.image = pygame.image.load("../graphics/test/player.png").convert_alpha()
		self.rect = self.image.get_rect(center = pos)
		self.hitbox = self.rect.inflate(-6, hitbox_offset["player"])

		# graphics state
		self.attacking = False
		self.state = "down"
		self.animations = {
			"up": [], "down": [], "right": [], "left": [],
			"up_idle": [], "down_idle": [], "right_idle": [], "left_idle": [],
			"up_attack": [], "down_attack": [], "right_attack": [], "left_attack": []
		}
		self.animations_path = "../graphics/player/"
		self.particles = particles

		self.import_animations()

		# audio set-up
		self.attack_audio = pygame.mixer.Sound("../audio/sword.wav")
		self.attack_audio.set_volume(0.1)

		# stats
		self.max_upgrade_stats = {"health": 300, "energy": 140, "attack": 20, "magic": 10,"speed": 10}
		self.max_stats = {"health":100, "energy": 100, "attack": 10, "magic": 4,"speed": 5}
		self.stats = {"health": self.max_stats["health"], "energy": self.max_stats["energy"], "exp": 0}
		self.upgrade_cost = {"health": 100, "energy": 100, "attack": 100, "magic": 100,"speed": 100}

		# movement
		self.vector = pygame.math.Vector2()
		self.velocity = self.max_stats["speed"]

		# sprites
		self.visible_sprites = visible_sprites
		self.attack_sprites = attack_sprites

		# weapons
		self.arsenal = arsenal
		self.weapon = None
		self.weapons = ["sword", "lance", "axe", "rapier", "sai"]
		self.weapon_index = 0
		self.weapon_change = False
		self.weapon_change_time = 0
		self.weapon_change_cooldown = 200

		# magic
		self.spells_surfaces = {k: import_surfaces(v["graphic"]) for k, v in spells.items()}
		self.spells = list(spells.keys())
		self.spell_index = 0
		self.spell_change = False
		self.spell_change_time = 0
		self.spell_change_cooldown = 200
		self.spell_type = self.spells[self.spell_index]

		# timers
		self.current_time = pygame.time.get_ticks()
			# physical attacks
		self.attack_time = 0
		self.attack_cooldown = self.arsenal[self.weapons[self.weapon_index]]["cooldown"]
			# magic
		self.casting = False
		self.can_cast = True
		self.cast_time = 0
		self.cast_cooldown = 250

		# damage stats
		self.damage = self.max_stats["attack"] + self.arsenal[self.weapons[self.weapon_index]]["damage"]

		self.kill_screen = kill_screen

	def input(self):
		# movement input
		keys = pygame.key.get_pressed()

		if not self.attacking and not self.casting:	
			if keys[pygame.K_w]:
				self.vector.y = -1
				self.state = "up"
			elif keys[pygame.K_s]:
				self.vector.y = 1
				self.state = "down"
			else:
				self.vector.y = 0

			if keys[pygame.K_a]:
				self.vector.x = -1
				self.state = "left"
			elif keys[pygame.K_d]:
				self.vector.x = 1
				self.state = "right"
			else:
				self.vector.x = 0

			if keys[pygame.K_q] and not self.weapon_change:
				self.weapon_index += 1
				if self.weapon_index >= len(self.arsenal.keys()):
					self.weapon_index = 0
				self.weapon_change_time = pygame.time.get_ticks()
				self.weapon_change = True

			if keys[pygame.K_e] and not self.spell_change:
				self.spell_index += 1
				if self.spell_index >= len(self.spells):
					self.spell_index = 0
				self.spell_type = self.spells[self.spell_index]
				self.spell_change_time = pygame.time.get_ticks()
				self.spell_change = True

		# attacking input
			if keys[pygame.K_SPACE] and self.attack_delay():
				self.attack()

			if keys[pygame.K_LALT]:
				self.cast_spell()

		else:
			self.vector.update((0, 0))

	def update_state(self):
		if self.attacking or self.casting:
			if "_attack" not in self.state:
				if"_idle" not in self.state:
					self.state = f"{self.state}_attack"
				else:
					self.state = self.state.replace("_idle", "_attack")

		elif self.vector == (0, 0):
			if "_idle" not in self.state:
				if "_attack" not in self.state:
					self.state = f"{self.state}_idle"
				else:
					self.state = self.state.replace("_attack", "_idle")

	def attack(self):
		state = self.state.split("_")[0]
		self.attacking = True
		self.attack_time = pygame.time.get_ticks()
		self.damage = self.max_stats["attack"] + self.arsenal[self.weapons[self.weapon_index]]["damage"]
		self.weapon = Weapon(self.arsenal[self.weapons[self.weapon_index]]["surfaces"][state],
			self.hitbox, state,
			[self.visible_sprites, self.attack_sprites]
		)
		self.attack_audio.play()

	def cast_spell(self):
		cost = spells[self.spell_type]["cost"]

		if self.check_energy(cost) and self.can_cast:
			state = self.state.split("_")[0]
			if self.spell_type == "heal":
				particles = (self.particles["heal"], self.particles["aura"])
			else:
				particles = self.particles[self.spell_type]

			self.spell = Magic(self.spell_type, particles, self.rect.center, state, [self.visible_sprites, self.attack_sprites])
			self.spell.cast_spell()
			self.casting = True
			self.can_cast = False
			self.cast_time = pygame.time.get_ticks()
			self.damage = self.max_stats["magic"] + spells[self.spell_type]["strength"]
			
			self.stats["energy"] -= cost
			if spells[self.spell_type]["type"] == "white magic":
				self.stats["health"] += self.damage
				self.check_max_health()

	def check_max_health(self):
		if self.stats["health"] > self.max_stats["health"]:
			self.stats["health"] = self.max_stats["health"]

	def check_energy(self, cost):
		if self.stats["energy"] >= cost:
			return True
		return False

	def energy_recovery(self):
		if self.stats["energy"] < self.max_stats["energy"]:
			self.stats["energy"] += 0.01 * self.max_stats["magic"]

	def extended_cooldowns(self):
		self.cooldowns()

		if (self.current_time - self.weapon_change_time) >= self.weapon_change_cooldown:
			self.weapon_change = False

		if (self.current_time - self.cast_time) >= self.cast_cooldown:
			self.casting = False

		if (self.current_time - self.cast_time) >= self.cast_cooldown * 3.75:
			self.can_cast = True

		if (self.current_time - self.spell_change_time) >= self.spell_change_cooldown:
			self.spell_change = False

	def die(self):
		if self.stats["health"] <= 0:
			self.kill_screen()

	def update(self):
		self.die()
		self.energy_recovery()
		self.update_state()
		self.animate()
		self.input()
		self.extended_cooldowns()
		self.move()