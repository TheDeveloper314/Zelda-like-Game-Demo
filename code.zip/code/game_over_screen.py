import pygame
from settings import *

class GameOverScreen():
	def __init__(self):
		self.display_surface = pygame.display.get_surface()
		self.centerx = self.display_surface.get_size()[0] / 2
		self.centery = self.display_surface.get_size()[1] / 2
		self.font = pygame.font.Font("../graphics/font/joystix.ttf", 20)

	def generate_text(self, text, posy):
		text_surface = self.font.render(text, False, text_colour)
		text_rect = text_surface.get_rect(center = (self.centerx, posy))
		return (text_surface, text_rect)

	def generate_player_image(self):
		player_image = pygame.image.load("../graphics/player/down_idle/idle_down.png").convert_alpha()
		player_image = pygame.transform.rotozoom(player_image, 0, 1.25)
		player_rect = player_image.get_rect(center = (self.centerx, self.centery))
		return (player_image, player_rect)